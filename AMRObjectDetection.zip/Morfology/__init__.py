from Morfology.GeodesicMethods import dilatate
from Morfology.GeodesicMethods import opening
from Morfology.GeodesicMethods import close

from Morfology.AMR import reconstructionAdaptative

from Morfology.Seeds import watershed as seeds
