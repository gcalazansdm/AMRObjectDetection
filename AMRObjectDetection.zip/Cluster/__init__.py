from Cluster.SpectralCluster import cluster
from Cluster.KNN import KNN
from Cluster.KNN import loadKNN
